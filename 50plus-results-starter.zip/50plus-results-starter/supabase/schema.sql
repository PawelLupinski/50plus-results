-- 50+ RESULTS MVP schema. Run this in Supabase SQL Editor.
-- Row Level Security is enabled; each user can access only rows with their own user_id.
create extension if not exists pgcrypto;

create table if not exists public.measurements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  measured_on date not null default current_date,
  weight_kg numeric(5,1) check (weight_kg is null or (weight_kg >= 20 and weight_kg <= 400)),
  waist_cm numeric(5,1) check (waist_cm is null or (waist_cm >= 30 and waist_cm <= 250)),
  notes text check (notes is null or char_length(notes) <= 500),
  created_at timestamptz not null default now(),
  constraint measurements_has_value check (weight_kg is not null or waist_cm is not null or notes is not null)
);
alter table public.measurements enable row level security;
drop policy if exists "Users can read own measurements" on public.measurements;
create policy "Users can read own measurements" on public.measurements for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own measurements" on public.measurements;
create policy "Users can insert own measurements" on public.measurements for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own measurements" on public.measurements;
create policy "Users can update own measurements" on public.measurements for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own measurements" on public.measurements;
create policy "Users can delete own measurements" on public.measurements for delete to authenticated using (auth.uid() = user_id);

create table if not exists public.workouts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  workout_date date not null default current_date,
  workout_type text not null check (workout_type in ('Siłowy','Kardio','Spacer','Pływanie','Mobilność','Inny')),
  duration_minutes integer check (duration_minutes is null or (duration_minutes between 1 and 600)),
  effort integer check (effort is null or (effort between 1 and 10)),
  notes text check (notes is null or char_length(notes) <= 1000),
  created_at timestamptz not null default now()
);
alter table public.workouts enable row level security;
drop policy if exists "Users can read own workouts" on public.workouts;
create policy "Users can read own workouts" on public.workouts for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own workouts" on public.workouts;
create policy "Users can insert own workouts" on public.workouts for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own workouts" on public.workouts;
create policy "Users can update own workouts" on public.workouts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own workouts" on public.workouts;
create policy "Users can delete own workouts" on public.workouts for delete to authenticated using (auth.uid() = user_id);

-- A trigger fills user_id from the authenticated session and prevents spoofing user IDs.
create or replace function public.set_row_user_id()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  new.user_id := auth.uid();
  return new;
end;
$$;
drop trigger if exists set_measurement_user_id on public.measurements;
create trigger set_measurement_user_id before insert on public.measurements
for each row execute function public.set_row_user_id();
drop trigger if exists set_workout_user_id on public.workouts;
create trigger set_workout_user_id before insert on public.workouts
for each row execute function public.set_row_user_id();

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.measurements to authenticated;
grant select, insert, update, delete on public.workouts to authenticated;
