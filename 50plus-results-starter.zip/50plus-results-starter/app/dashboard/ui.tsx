"use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Measurement = { id: string; measured_on: string; weight_kg: number | null; waist_cm: number | null; notes: string | null };
type Workout = { id: string; workout_date: string; workout_type: string; duration_minutes: number | null; notes: string | null; effort: number | null };

export default function Dashboard({ email, initialMeasurements, initialWorkouts }: { email: string; initialMeasurements: Measurement[]; initialWorkouts: Workout[] }) {
  const [tab, setTab] = useState<"overview" | "measurements" | "workouts">("overview");
  const [measurements, setMeasurements] = useState(initialMeasurements);
  const [workouts, setWorkouts] = useState(initialWorkouts);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function saveMeasurement(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage("");
    const formElement = e.currentTarget;
    const form = new FormData(formElement);
    const weight = String(form.get("weight") ?? "").trim();
    const waist = String(form.get("waist") ?? "").trim();
    const row = { measured_on: String(form.get("date")), weight_kg: weight ? Number(weight) : null, waist_cm: waist ? Number(waist) : null, notes: String(form.get("notes") ?? "").trim() || null };
    try {
      const supabase = createClient();
      const { data, error } = await supabase.from("measurements").insert(row).select().single();
      if (error) throw error;
      setMeasurements(prev => [data, ...prev].slice(0, 12)); formElement.reset(); setMessage("Pomiar zapisany w bazie.");
    } catch (err) { setMessage(err instanceof Error ? err.message : "Nie udało się zapisać pomiaru."); }
    finally { setBusy(false); }
  }

  async function saveWorkout(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage("");
    const formElement = e.currentTarget;
    const form = new FormData(formElement);
    const duration = String(form.get("duration") ?? "").trim();
    const effort = String(form.get("effort") ?? "").trim();
    const row = { workout_date: String(form.get("date")), workout_type: String(form.get("type")), duration_minutes: duration ? Number(duration) : null, effort: effort ? Number(effort) : null, notes: String(form.get("notes") ?? "").trim() || null };
    try {
      const supabase = createClient();
      const { data, error } = await supabase.from("workouts").insert(row).select().single();
      if (error) throw error;
      setWorkouts(prev => [data, ...prev].slice(0, 10)); formElement.reset(); setMessage("Trening zapisany w bazie.");
    } catch (err) { setMessage(err instanceof Error ? err.message : "Nie udało się zapisać treningu."); }
    finally { setBusy(false); }
  }

  async function logout() {
    const supabase = createClient(); await supabase.auth.signOut(); window.location.href = "/login";
  }

  const latest = measurements[0];
  const firstWeight = [...measurements].reverse().find(m => m.weight_kg !== null)?.weight_kg;
  const latestWeight = measurements.find(m => m.weight_kg !== null)?.weight_kg;
  const change = firstWeight !== undefined && latestWeight !== undefined ? latestWeight - firstWeight : null;

  return <main className="app-shell">
    <header className="topbar"><div className="brand-inline"><span className="mini-mark">50+</span><span>50+ <b>RESULTS</b></span></div><div className="account"><span>{email}</span><button className="ghost" onClick={logout}>Wyloguj</button></div></header>
    <section className="welcome"><div><p className="eyebrow">TWÓJ PLAN • TWÓJ POSTĘP</p><h1>Witaj w 50+ RESULTS</h1><p className="muted">Regularność jest ważniejsza niż perfekcja. Zapisuj małe kroki.</p></div><div className="today-chip">{new Date().toLocaleDateString("pl-PL", {weekday:"long", day:"numeric", month:"long"})}</div></section>
    <nav className="tabs">
      <button className={tab === "overview" ? "active" : ""} onClick={() => {setTab("overview");setMessage("");}}>Dashboard</button>
      <button className={tab === "measurements" ? "active" : ""} onClick={() => {setTab("measurements");setMessage("");}}>Pomiary</button>
      <button className={tab === "workouts" ? "active" : ""} onClick={() => {setTab("workouts");setMessage("");}}>Dziennik treningowy</button>
    </nav>
    {message && <p className="notice global-notice" role="status">{message}</p>}
    {tab === "overview" && <section className="content-grid">
      <article className="panel hero-panel"><p className="eyebrow">NAJWAŻNIEJSZE</p><h2>Postęp, który możesz zmierzyć.</h2><p className="muted">Pierwsza wersja zapisuje pomiary i treningi na Twoim koncie. Wykresy, cele i przypomnienia dodamy po sprawdzeniu podstaw.</p><div className="hero-stats"><div><span>Ostatnia waga</span><strong>{latestWeight != null ? `${latestWeight} kg` : "—"}</strong></div><div><span>Zmiana od pierwszego pomiaru</span><strong>{change !== null ? `${change > 0 ? "+" : ""}${change.toFixed(1)} kg` : "—"}</strong></div><div><span>Treningi zapisane</span><strong>{workouts.length}</strong></div></div></article>
      <article className="panel"><h3>Szybki pomiar</h3><p className="muted small">Zapisz wagę i obwód talii.</p><MeasurementForm onSubmit={saveMeasurement} busy={busy} /></article>
      <article className="panel"><h3>Zapisz trening</h3><p className="muted small">Rodzaj, czas i odczuwana intensywność.</p><WorkoutForm onSubmit={saveWorkout} busy={busy} /></article>
      <article className="panel"><h3>Ostatnie wpisy</h3><h4>Pomiary</h4>{measurements.length ? <ul className="entry-list">{measurements.slice(0,3).map(m=><li key={m.id}><span>{m.measured_on}</span><b>{m.weight_kg != null ? `${m.weight_kg} kg` : "—"} · {m.waist_cm != null ? `${m.waist_cm} cm talii` : "bez talii"}</b></li>)}</ul> : <p className="muted small">Nie ma jeszcze pomiarów.</p>}<h4>Treningi</h4>{workouts.length ? <ul className="entry-list">{workouts.slice(0,3).map(w=><li key={w.id}><span>{w.workout_date}</span><b>{w.workout_type}{w.duration_minutes ? ` · ${w.duration_minutes} min` : ""}</b></li>)}</ul> : <p className="muted small">Nie ma jeszcze treningów.</p>}</article>
    </section>}
    {tab === "measurements" && <section className="two-col"><article className="panel"><h2>Dodaj pomiar</h2><MeasurementForm onSubmit={saveMeasurement} busy={busy} /></article><article className="panel"><h2>Historia pomiarów</h2>{measurements.length ? <div className="table-wrap"><table><thead><tr><th>Data</th><th>Waga</th><th>Talia</th><th>Notatka</th></tr></thead><tbody>{measurements.map(m=><tr key={m.id}><td>{m.measured_on}</td><td>{m.weight_kg != null ? `${m.weight_kg} kg` : "—"}</td><td>{m.waist_cm != null ? `${m.waist_cm} cm` : "—"}</td><td>{m.notes || "—"}</td></tr>)}</tbody></table></div> : <p className="muted">Dodaj pierwszy pomiar, aby rozpocząć historię.</p>}</article></section>}
    {tab === "workouts" && <section className="two-col"><article className="panel"><h2>Nowy trening</h2><WorkoutForm onSubmit={saveWorkout} busy={busy} /></article><article className="panel"><h2>Historia treningów</h2>{workouts.length ? <div className="table-wrap"><table><thead><tr><th>Data</th><th>Typ</th><th>Czas</th><th>RPE</th><th>Notatka</th></tr></thead><tbody>{workouts.map(w=><tr key={w.id}><td>{w.workout_date}</td><td>{w.workout_type}</td><td>{w.duration_minutes != null ? `${w.duration_minutes} min` : "—"}</td><td>{w.effort ?? "—"}</td><td>{w.notes || "—"}</td></tr>)}</tbody></table></div> : <p className="muted">Zapisz pierwszy trening.</p>}</article></section>}
    <footer>Wersja pilotażowa • Nie jest poradą medyczną. Trenuj w granicach swoich możliwości.</footer>
  </main>;
}

function MeasurementForm({ onSubmit, busy }: { onSubmit: (e: FormEvent<HTMLFormElement>) => void; busy: boolean }) {
  return <form className="stack" onSubmit={onSubmit}><label>Data<input name="date" type="date" defaultValue={new Date().toLocaleDateString("en-CA")} required /></label><div className="form-row"><label>Waga (kg)<input name="weight" type="number" min="20" max="400" step="0.1" placeholder="np. 112.0" /></label><label>Talia (cm)<input name="waist" type="number" min="30" max="250" step="0.1" placeholder="np. 108" /></label></div><label>Notatka (opcjonalnie)<input name="notes" maxLength={500} placeholder="np. rano, przed śniadaniem" /></label><button className="primary" disabled={busy}>Zapisz pomiar</button></form>;
}
function WorkoutForm({ onSubmit, busy }: { onSubmit: (e: FormEvent<HTMLFormElement>) => void; busy: boolean }) {
  return <form className="stack" onSubmit={onSubmit}><label>Data<input name="date" type="date" defaultValue={new Date().toLocaleDateString("en-CA")} required /></label><label>Rodzaj treningu<select name="type" required defaultValue="Siłowy"><option>Siłowy</option><option>Kardio</option><option>Spacer</option><option>Pływanie</option><option>Mobilność</option><option>Inny</option></select></label><div className="form-row"><label>Czas (min)<input name="duration" type="number" min="1" max="600" step="1" placeholder="np. 45" /></label><label>Intensywność (RPE 1–10)<input name="effort" type="number" min="1" max="10" step="1" placeholder="np. 6" /></label></div><label>Notatka (opcjonalnie)<input name="notes" maxLength={1000} placeholder="ćwiczenia, serie, obciążenia…" /></label><button className="primary" disabled={busy}>Zapisz trening</button></form>;
}
