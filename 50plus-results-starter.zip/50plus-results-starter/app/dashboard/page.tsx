import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Dashboard from "./ui";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const [{ data: measurements }, { data: workouts }] = await Promise.all([
    supabase.from("measurements").select("*").order("measured_on", { ascending: false }).limit(12),
    supabase.from("workouts").select("*").order("workout_date", { ascending: false }).limit(10),
  ]);
  return <Dashboard email={user.email ?? ""} initialMeasurements={measurements ?? []} initialWorkouts={workouts ?? []} />;
}
