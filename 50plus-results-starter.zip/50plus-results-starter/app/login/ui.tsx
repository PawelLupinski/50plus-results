 "use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AuthForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase = createClient();
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.session) { window.location.href = "/dashboard"; }
        else { setMessage("Sprawdź pocztę i potwierdź adres, a następnie zaloguj się."); }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        window.location.href = "/dashboard";
      }
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Wystąpił błąd.");
    } finally { setBusy(false); }
  }

  return <form onSubmit={submit} className="stack">
    <div className="mode-switch">
      <button type="button" className={mode === "signup" ? "selected" : ""} onClick={() => {setMode("signup"); setMessage("");}}>Utwórz konto</button>
      <button type="button" className={mode === "login" ? "selected" : ""} onClick={() => {setMode("login"); setMessage("");}}>Logowanie</button>
    </div>
    <label>Email<input type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} /></label>
    <label>Hasło (minimum 8 znaków)<input type="password" minLength={8} autoComplete={mode === "login" ? "current-password" : "new-password"} required value={password} onChange={e => setPassword(e.target.value)} /></label>
    <button className="primary" disabled={busy}>{busy ? "Chwileczkę…" : mode === "signup" ? "Utwórz konto" : "Zaloguj się"}</button>
    {message && <p className="notice" role="status">{message}</p>}
  </form>;
}
