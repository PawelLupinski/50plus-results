import AuthForm from "./ui";

export default function LoginPage() {
  return <main className="auth-shell">
    <section className="brand-panel">
      <div className="brand-mark">50+</div>
      <p className="eyebrow">SMALL STEPS. REAL RESULTS.</p>
      <h1>50+ RESULTS</h1>
      <p className="muted light">Mierz postęp. Trenuj rozsądnie. Buduj regularność.</p>
      <div className="brand-note">Twoje dane są prywatne — konto widzi tylko własne wpisy.</div>
    </section>
    <section className="auth-card">
      <h2>Twoje konto</h2>
      <p className="muted">Zaloguj się lub utwórz konto testowe.</p>
      <AuthForm />
      <p className="small muted">Na etapie pilota nie wpisuj diagnoz, wyników badań ani innych szczegółowych danych medycznych.</p>
    </section>
  </main>;
}
