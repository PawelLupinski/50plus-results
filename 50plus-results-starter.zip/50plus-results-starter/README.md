# 50+ RESULTS — MVP starter

This is a **starter project**, not a deployed or verified production application. It contains a first-pass UI, Supabase email/password auth, measurement and workout forms, and SQL schema with Row Level Security (RLS).

## What is included
- Sign-up and sign-in by email/password
- Dashboard that reads recent measurements and workouts from Supabase
- Persistent entries for weight, waist, workout type, duration, perceived effort (RPE), notes
- Database ownership rules using Supabase RLS
- Responsive UI for mobile and desktop

## What is not yet included
- Tested production deployment, automated tests, password reset, account deletion/export UI
- Full privacy notice/consent flow, legal review, monitoring, backups on a paid tier
- Editing/deleting entries from the UI, charts, exercise library, goals, notifications
- Health/medical history or coaching/diagnostic recommendations

## Prerequisites
1. A Supabase account: https://supabase.com/
2. Node.js LTS: https://nodejs.org/
3. (Optional for public hosting) GitHub: https://github.com/ and Vercel: https://vercel.com/

## Setup
1. Create a new Supabase project.
2. In Supabase, open **SQL Editor**, paste and run `supabase/schema.sql`.
3. In Supabase project settings, find the Project URL and publishable/anon key.
4. Copy `.env.example` to `.env.local` and fill in:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   Never put a `service_role` key in this file or in browser code.
5. Install Node.js LTS. Open a terminal in this folder and run:
   ```bash
   npm install
   npm run dev
   ```
6. Open http://localhost:3000.
7. Create a test account, confirm email if required by your Supabase auth settings, sign in, save a measurement and a workout, refresh the page, and confirm they remain visible.

## Email confirmation
For local testing, configure the Supabase Auth URL settings to include `http://localhost:3000` as a redirect/site URL. Depending on project settings, sign-up may require email confirmation. This starter uses a simple client flow; email confirmation redirects and password recovery should be implemented before a wider pilot.

## Deploy later
After local tests, push the project to a private GitHub repository and import it into Vercel. Add the two public Supabase environment variables in Vercel project settings. Configure the production URL in Supabase Auth URL settings. Do not invite pilot users until auth, RLS isolation, backups, privacy notice, and deletion/export processes have been tested.

## Privacy and pilot safety
Weight, measurements and training logs can be personal data; health-related details may be special-category data under UK GDPR. For the first pilot, collect only data needed for the product and avoid diagnoses, medication lists and clinical test results. Before inviting other people, document the lawful basis and any Article 9 condition that applies, publish a privacy notice, set retention/deletion rules, assess whether an ICO fee applies, and consider a DPIA. Seek appropriate advice if unsure.

## Cost guide (verify before launch)
- Supabase Free: $0; useful for initial experiments, but projects may pause after inactivity.
- Vercel Hobby: $0 for personal/non-commercial use; check terms before using it for a public/commercial pilot.
- Domain: optional, commonly paid annually; price depends on the domain ending and registrar.
- Supabase Pro: currently listed from $25/month if you need production-oriented features such as non-pausing projects and daily backups.
- Vercel Pro: currently listed at $20/month; may be unnecessary for an early private test.
Prices may change and taxes/currency conversion may apply.
